package com.example.best_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
