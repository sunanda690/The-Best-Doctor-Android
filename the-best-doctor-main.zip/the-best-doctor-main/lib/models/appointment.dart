import 'dart:convert';
import 'package:flutter/widgets.dart';

class Appointment{
  final int? appointment_id;
  final String appointment_date;
  final String appointment_time;
  final int patient_id;
  final int doctor_id;

  Appointment({
    this.appointment_id,
    required this.appointment_date,
    required this.appointment_time,
    required this.patient_id,
    required this.doctor_id,
  });

  Map<String, dynamic> toMap() {
    return {
      'appointment_date': appointment_date,
      'appointment_time': appointment_time,
      'patient_id' : patient_id,
      'doctor_id' : doctor_id,
    };
  }

  factory Appointment.fromMap(Map<String, dynamic> map) {
    return Appointment(
      appointment_id: map['appointment_id'].toInt() ,
      appointment_time: map['appointment_time'] ?? '',
      appointment_date: map['appointment_date'] ?? '',
      patient_id: map['patient_id']?.toInt() ?? 0,
      doctor_id: map['doctor_id']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory Appointment.fromJson(String source) => Appointment.fromMap(json.decode(source));

}