import 'dart:convert';
import 'package:flutter/widgets.dart';

class Symptom{
  final int? symptom_id;
  final String name;

  Symptom({
    this.symptom_id,
    required this.name,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
    };
  }

  factory Symptom.fromMap(Map<String, dynamic> map) {
    return Symptom(
      symptom_id: map['symptom_id'].toInt(),
      name: map['name'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Symptom.fromJson(String source) => Symptom.fromMap(json.decode(source));

}