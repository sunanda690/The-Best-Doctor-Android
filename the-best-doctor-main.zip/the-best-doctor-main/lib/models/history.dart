import 'dart:convert';
import 'package:flutter/widgets.dart';

class History{
  final int ? history_id;
  final int appointment_id;
  final int patient_id;

  History({
    this.history_id,
    required this.appointment_id,
    required this.patient_id,
  });

  Map<String, dynamic> toMap() {
    return {
      'appointment_id': appointment_id,
      'patient_id' : patient_id,
    };
  }

  factory History.fromMap(Map<String, dynamic> map) {
    return History(
      history_id: map['history_id'].toInt(),
      appointment_id: map['appointment_id']?.toInt() ?? 0,
      patient_id: map['patient_id']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory History.fromJson(String source) => History.fromMap(json.decode(source));

}