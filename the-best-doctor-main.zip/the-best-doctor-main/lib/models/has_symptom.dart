import 'dart:convert';
import 'package:flutter/widgets.dart';

class HasSymptom{
  final int symptom_id ;
  final int patient_id;

  HasSymptom({
    required this.symptom_id,
    required this.patient_id,
  });

  Map<String, dynamic> toMap() {
    return {
      'symptom_id': symptom_id,
      'patient_id': patient_id,
    };
  }

  factory HasSymptom.fromMap(Map<String, dynamic> map) {
    return HasSymptom(
      symptom_id: map['symptom_id']?.toInt() ?? 0,
      patient_id: map['patient_id']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory HasSymptom.fromJson(String source) => HasSymptom.fromMap(json.decode(source));

}