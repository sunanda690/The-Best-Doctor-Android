import 'dart:convert';
import 'package:flutter/widgets.dart';

class Slot{
  final int ? slot_id;
  final String start_time;
  final String end_time;

  Slot({
    this.slot_id,
    required this.start_time,
    required this.end_time,
  });

  Map<String, dynamic> toMap() {
    return {
      'start_time': start_time,
      'end_time' : end_time,
    };
  }

  factory Slot.fromMap(Map<String, dynamic> map) {
    return Slot(
      slot_id: map['slot_id'].toInt(),
      start_time: map['start_time'],
      end_time: map['end_time'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Slot.fromJson(String source) => Slot.fromMap(json.decode(source));

}