import 'dart:convert';
import 'package:flutter/widgets.dart';

class Specialization{
  final int? spec_id;
  final String speciality;

  Specialization({
    this.spec_id,
    required this.speciality,
  });

  Map<String, dynamic> toMap() {
    return {
      'speciality': speciality,
    };
  }

  factory Specialization.fromMap(Map<String, dynamic> map) {
    return Specialization(
      spec_id: map['spec_id'].toInt(),
      speciality: map['speciality'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Specialization.fromJson(String source) => Specialization.fromMap(json.decode(source));

}