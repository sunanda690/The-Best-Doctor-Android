import 'dart:convert';
import 'package:flutter/widgets.dart';

class Patient{
  final int ? patient_id;
  final String username;
  final String name;
  final String email;
  final String password;
  final String mobile_number;
  final int age;

  Patient({
    this.patient_id,
    required this.username,
    required this.name,
    required this.email,
    required this.password,
    required this.mobile_number,
    required this.age,
  });

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'name': name,
      'email': email,
      'password' : password,
      'mobile_number' : mobile_number,
      'age': age,
    };
  }

  factory Patient.fromMap(Map<String, dynamic> map) {
    return Patient(
      patient_id: map['patient_id']?.toInt() ?? -1,
      username: map['username'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      password: map['password'] ?? '',
      mobile_number: map['mobile_number'] ?? '',
      age: map['age']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory Patient.fromJson(String source) => Patient.fromMap(json.decode(source));

}