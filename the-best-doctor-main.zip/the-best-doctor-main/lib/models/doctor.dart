import 'dart:convert';
import 'package:flutter/widgets.dart';

class Doctor{
  final int? doctor_id;
  final String username;
  final String name;
  final String email;
  final String password;
  final String mobile_number;
  final int age;
  final int experience;

  Doctor({
    this.doctor_id,
    required this.username,
    required this.name,
    required this.email,
    required this.password,
    required this.mobile_number,
    required this.age,
    required this.experience,
  });

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'name': name,
      'email': email,
      'password' : password,
      'mobile_number' : mobile_number,
      'age': age,
      'experience' : experience,
    };
  }

  factory Doctor.fromMap(Map<String, dynamic> map) {
    return Doctor(
      doctor_id: map['doctor_id']?.toInt() ?? 0,
      username: map['username'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      password: map['password'] ?? '',
      mobile_number: map['mobile_number'] ?? '',
      age: map['age']?.toInt() ?? 0,
      experience: map['experience']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory Doctor.fromJson(String source) => Doctor.fromMap(json.decode(source));

}