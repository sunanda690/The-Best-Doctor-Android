import 'dart:convert';
import 'package:flutter/widgets.dart';

class Specialized{
  final int spec_id;
  final int doctor_id;

  Specialized({
    required this.spec_id,
    required this.doctor_id,
  });

  Map<String, dynamic> toMap() {
    return {
      'spec_id': spec_id,
      'doctor_id': doctor_id,
    };
  }

  factory Specialized.fromMap(Map<String, dynamic> map) {
    return Specialized(
      spec_id: map['spec_id']?.toInt() ?? 0,
      doctor_id: map['doctor_id']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory Specialized.fromJson(String source) => Specialized.fromMap(json.decode(source));

}