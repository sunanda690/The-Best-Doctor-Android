import 'package:best_doctor/models/appointment.dart';
import 'package:best_doctor/models/history.dart';
import 'package:best_doctor/models/patient.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:path/path.dart';

import '../services/database_service.dart';

class Appcard extends StatefulWidget {
  const Appcard({
    Key? key,
    required this.app,
    required this.done,
    required this.delete,
  }) : super(key: key);
  final Appointment app;
  final VoidCallback done;
  final VoidCallback delete;

  @override
  _AppCardState createState() => _AppCardState();
}

class _AppCardState extends State<Appcard>{
  final DatabaseService _databaseService = DatabaseService();
  // Future<Patient> _getPatient() async {
  //   return await _databaseService.getPatientName(widget.app.patient_id);
  // }

  _delete(BuildContext context ) async {
    await _databaseService.deleteApp(widget.app.appointment_id);
    // await _databaseService.insertHistory(History(appointment_id: widget.app.appointment_id ?? 0, patient_id: widget.app.patient_id ?? 0));
  }

  _done(BuildContext context ) async {
    int appid  = widget.app.appointment_id ?? 0;
    await _databaseService.deleteApp(appid);
    await _databaseService.insertHistory(History(appointment_id: appid, patient_id: widget.app.patient_id ));
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    int id = widget.app.appointment_id ?? 1;
    // Patient patient = _getPatient() as Patient;
    String name = 'Sunanda Mandal';
    int age = 25;
    String date =  widget.app.appointment_date;
    String time =  widget.app.appointment_time;
    return Card(
      child:Container(
        height: size.height *0.3,
        color: Colors.white,

        child: Row(
          children: [
            Center(
              child: Padding(
                padding: EdgeInsets.all(10),
                child: SvgPicture.asset(
                  "assets/icons/signup.svg",
                  height: size.height * 0.18,
                ),
              ),
            ),
            Container(
              width: size.width *0.5,
              child: Column(
                children: [
                  ListTile(
                    title: Text("Appointment $id"),
                    subtitle: Text("Patient Nme: $name \nAge: $age \nDate: $date, Time: $time"),
                  ),
                  // Text(
                  //   "Date: $date, Time: $time"
                  // ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        child:Text("Mark as Done"),
                        onPressed: () => _delete(context),
                      ),
                      SizedBox(width: 8,),
                      TextButton(
                        child: Text("DELETE"),
                        onPressed: () => _done(context),
                      ),
                      SizedBox(width: 8,)
                    ],
                  )
                ],
              )
            )
          ],
        )
      ),
      elevation: 8,
      margin: EdgeInsets.all(10),
    );
  }
}
