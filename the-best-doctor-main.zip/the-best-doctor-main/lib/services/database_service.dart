import 'package:best_doctor/models/appointment.dart';
import 'package:best_doctor/models/doctor.dart';
import 'package:best_doctor/models/has_symptom.dart';
import 'package:best_doctor/models/history.dart';
import 'package:best_doctor/models/patient.dart';
import 'package:best_doctor/models/specialization.dart';
import 'package:best_doctor/models/specialized.dart';
import 'package:best_doctor/models/symptom.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  // Singleton pattern
  static final DatabaseService _databaseService = DatabaseService._internal();
  factory DatabaseService() => _databaseService;
  DatabaseService._internal();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    // Initialize the DB first time it is accessed
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    print(databasePath);
    final path = join(databasePath, 'doc5.db');
 // path to perform database upgrades and downgrades.
    return await openDatabase(
      path,
      onCreate: _onCreate,
      version: 1,
      onConfigure: (db) async => await db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  // When the database is first created, create a table to store breeds
  // and a table to store dogs.
  Future<void> _onCreate(Database db, int version) async {
    await db.execute(
      'CREATE TABLE patients ( patient_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username VARCHAR(255) NOT NULL UNIQUE, name VARCHAR(255) NOT NULL,email VARCHAR(255) NOT NULL,password VARCHAR(255) NOT NULL,mobile_number VARCHAR(255) NOT NULL,age int NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE doctors ( doctor_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username VARCHAR(255) NOT NULL UNIQUE, name VARCHAR(255) NOT NULL,email VARCHAR(255) NOT NULL,password VARCHAR(255) NOT NULL,mobile_number VARCHAR(255) NOT NULL,age int NOT NULL, experience int NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE appointments ( appointment_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,appointment_date DATE NOT NULL,appointment_time TIME NOT NULL,patient_id INTEGER NOT NULL,doctor_id INTEGER NOT NULL,FOREIGN KEY(patient_id) references patients,FOREIGN KEY(doctor_id) references doctors)',
    );
    await db.execute(
      'CREATE TABLE history (history_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, appointment_id INTEGER NOT NULL UNIQUE, patient_id INTEGER NOT NULL, FOREIGN KEY(patient_id) references patient, FOREIGN KEY(appointment_id) references appointments)',
    );
    await db.execute(
      'CREATE TABLE specialization (spec_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,speciality VARCHAR(255) NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE specialized (spec_id INTEGER,doctor_id INTEGER,PRIMARY KEY(spec_id, doctor_id),FOREIGN KEY(spec_id) REFERENCES specialization,FOREIGN KEY(doctor_id) REFERENCES doctor)'
    );
    await db.execute(
      'CREATE TABLE symptom (symptom_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,name VARCHAR(255) NOT NULL)'
    );
    await db.execute(
      'CREATE TABLE has_symptom (patient_id INTEGER NOT NULL,symptom_id INTEGER NOT NULL,PRIMARY KEY(patient_id, symptom_id),FOREIGN KEY(patient_id) references patient,FOREIGN KEY(symptom_id) references symptom)'
    );
    await db.execute(
      'CREATE TABLE slots (slot_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,start_time time NOT NULL, end_time time NOT NULL)'
    );
  }

  Future<void> insertPatient(Patient patient) async{
    final db = await _databaseService.database;
    await db.insert(
      'patients',
      patient.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Patient?> findPatient(String username, String password) async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps =
      await db.rawQuery('SELECT * FROM patients where username = ? and password = ?', [username, password]);
    // await db.query('patients', where: 'username = ? ans',, whereArgs: [id]);
    if( maps.isEmpty) {
      return null;
    }
    return Patient.fromMap(maps[0]);
  }

  Future<Patient> getPatientName(int id) async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps =
    await db.query('patients', where: 'patient_id = ?', whereArgs: [id]);
    return Patient.fromMap(maps[0]);
  }

  Future<void> insertDoctor(Doctor doctor) async{
    final db = await _databaseService.database;
    await db.insert(
      'doctors',
      doctor.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Doctor?> findDoctor(String username, String password) async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps =
    await db.rawQuery('SELECT * FROM doctors where username = ? and password = ?', [username, password]);
    // await db.query('patients', where: 'username = ? ans',, whereArgs: [id]);
    if( maps.isEmpty) {
      return null;
    }
    return Doctor.fromMap(maps[0]);
  }

  Future<void> insertAppointment(Appointment appointment) async{
    final db = await _databaseService.database;
    await db.insert(
      'appointments',
      appointment.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertHistory(History hist) async{
    final db = await _databaseService.database;
    await db.insert(
      'history',
      hist.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertSpecialization(Specialization spec) async{
    final db = await _databaseService.database;
    await db.insert(
      'specialization',
      spec.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertSpecialized(Specialized spec) async{
    final db = await _databaseService.database;
    await db.insert(
      'specialized',
      spec.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertSymptom(Symptom symp) async{
    final db = await _databaseService.database;
    await db.insert(
      'symptom',
      symp.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> insertHasSymptom(HasSymptom symp) async{
    final db = await _databaseService.database;
    await db.insert(
      'has_symptom',
      symp.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Appointment>> getApps() async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps = await db.query('appointments');
    return List.generate(maps.length, (index) => Appointment.fromMap(maps[index]));
  }

  Future<List<Map<String, dynamic>>> getHistory(int patientId) async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps =
    await db.rawQuery(
      'SELECT a.appointment_date, a.appointment_time, d.name FROM history h left join appointments a on a.patient_id=h.patient_id left join doctor d on d.doctor_id=a.doctor_id where h.patient_id=?;',[patientId]
    );
    print(maps);
    return maps;
  }
  Future<List<Map<String, dynamic>>> getHistoryDoc(int doctorId) async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps =
    await db.rawQuery(
        'SELECT a.appointment_date, a.appointment_time, d.name FROM history h left join appointments a on a.patient_id=h.patient_id left join doctor d on d.doctor_id=a.doctor_id where d.doctor_id=?;',[doctorId]
    );
    print(maps);
    return maps;
  }

  Future<int> getSpecId(String spec) async{
    final db = await _databaseService.database;
    List<Map<String, dynamic>> maps = await db.query('specialization',where: 'speciality=?', whereArgs: [spec]);
    if(maps.isEmpty) {
      return 0;
    }
    return maps[0]['spec_id'];
  }

  Future<List<Specialization>> getSpecs() async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps = await db.query('specialization');
    return List.generate(maps.length, (index) => Specialization.fromMap(maps[index]));
  }

  Future<List<Symptom>> getSymptoms() async {
    final db = await _databaseService.database;
    final List<Map<String, dynamic>> maps = await db.query('symptom');
    return List.generate(maps.length, (index) => Symptom.fromMap(maps[index]));
  }

  Future<void> deleteApp(int? id) async {
    final db = await _databaseService.database;
    await db.delete('appointments', where: 'appointment_id = ?', whereArgs: [id]);
  }


}
