import 'package:best_doctor/common_widgets/appcard.dart';
import 'package:best_doctor/models/appointment.dart';
import 'package:best_doctor/pages/login_page.dart';
import 'package:flutter/material.dart';
import 'package:best_doctor/services/database_service.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:best_doctor/theme/light_color.dart';
import 'package:best_doctor/theme/text_styles.dart';
import 'package:best_doctor/theme/extention.dart';
import 'package:best_doctor/theme/theme.dart';

import '../models/doctor.dart';
import '../models/patient.dart';


class DashboardDoc extends StatefulWidget {
  const DashboardDoc({Key? key, required this.doctor}) : super(key: key);
  final Doctor doctor;
  @override
  _DashboardDocState createState() => _DashboardDocState();
}

class _DashboardDocState extends State<DashboardDoc> {
  final DatabaseService _databaseService = DatabaseService();
  late List<Appointment> appList;
  int count = 0;

  // Future<List<Departments>> _getDeps() async {
  //   return await _databaseService.deps();
  // }

  Widget _header(String name) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        // String name = $widget.patient.name
        Text("Welcome $name", style: TextStyles.h1Style),
      ],
    ).p16;
  }


  Widget _appointmentList(Appointment appointment) {
    return SliverList(
      delegate: SliverChildListDelegate(
        [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text("Appointments", style: TextStyles.title.bold),
              IconButton(
                  icon: Icon(
                    Icons.sort,
                    color: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {})
              // .p(12).ripple(() {}, borderRadius: BorderRadius.all(Radius.circular(20))),
            ],
          ).hP16,
          Column(
          children: [
            Appcard(
              app: appointment,
              done: (){},
              delete: (){},
            )
          ],
          // getDepWidgetList()
          ),
          ]
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    // if (appList == null) {
    //   appList = List<Appointment>();
    //   updateListView();
    // }
    Appointment app = Appointment(appointment_date: '12-04-2022', appointment_time: '13:00', patient_id: 1, doctor_id: 1);
    Appointment app2 = Appointment(appointment_id:2 ,appointment_date: '31-03-2022', appointment_time: '17:00', patient_id: 1, doctor_id: 1);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('The Best Docor'),
          centerTitle: true,
          elevation: 0,
          // backgroundColor: Theme.of(context).backgroundColor,
          leading: Icon(
            Icons.short_text,
            size: 30,
            color: Colors.black,
          ),
          actions: <Widget>[
            Icon(
              Icons.notifications_none,
              size: 30,
              color: LightColor.grey,
            ),
            ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(13)),
              child: Container(
                // height: 40,
                // width: 40,
                decoration: BoxDecoration(
                  color: Theme.of(context).backgroundColor,
                ),
                child: Image.asset("assets/heartbeat.png", fit: BoxFit.fill),
              ),
            ).p(8),
          ],

          bottom: TabBar(
            tabs: [
              TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.all(16.0),
                  primary: Colors.cyanAccent,
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context){
                    return LoginScreen();
                  }));
                },
                child: Text('Update Pesonal Details'),
              ),
              TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.all(16.0),
                  primary: Colors.cyanAccent,
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context){
                    return LoginScreen();
                  }));
                },
                child: Text('View Appointments History'),
              ),
            ],
          ),
        ),
        // backgroundColor: Theme.of(context).backgroundColor,
        body: CustomScrollView(
          slivers: <Widget>[
            SliverList(
              delegate: SliverChildListDelegate(
                [
                  _header(widget.doctor.name),
                ],
              ),
            ),
            _appointmentList(app),
            _appointmentList(app2)
            // Column(
            //   children: [
            //     for( var i in appList){
            //       _appointmentList(i);
            //     }
            //   ],
            // )
          ],
        ),
      ),
    );
  }
  // void updateListView() {
  //   Future<List<Appointment>> appListFuture = _databaseService.getApps();
  //     appListFuture.then((appList) {
  //       setState(() {
  //         this.appList = appList;
  //         this.count = appList.length;
  //       });
  //     });
  //   });
  // }

}
