import 'package:best_doctor/models/doctor.dart';
import 'package:best_doctor/services/database_service.dart';
import 'package:flutter/material.dart';
import 'package:best_doctor/pages/background.dart';
import 'package:best_doctor/common_widgets/rounded_button.dart';
import 'package:best_doctor/common_widgets/rounded_input_field.dart';
import 'package:best_doctor/common_widgets/rounded_password_field.dart';
import 'package:flutter_svg/svg.dart';

import '../services/database_service.dart';
class SignUpDocScreen extends StatefulWidget {
  const SignUpDocScreen({Key? key}) : super(key: key);

  @override
  _SignUpDoScreenState createState() => _SignUpDoScreenState();
}

class _SignUpDoScreenState extends State<SignUpDocScreen>{
  final DatabaseService _databaseService = DatabaseService();

  String _username = '';
  String _name = '';
  String _email = '';
  String _password = '';
  String _mobile_number = '';
  int _age = 0;
  int _experience = 0;

  Future<void> _onLogin() async {
    final username = _username;
    final password = _password;
    final name = _name;
    final email = _email;
    final mobile_number = _mobile_number;
    final age = _age;
    final experience = _experience;

    print({username, password});

    await _databaseService.insertDoctor(
        Doctor(name: name, username: username, email: email, password: password, mobile_number: mobile_number, age: age, experience: experience)
    );

    // Navigator.pop(context);
  }

  Widget _body(Size size) {
    // Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "SIGNUP as Doctor",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: size.height * 0.03),
            SvgPicture.asset(
              "assets/icons/signup.svg",
              height: size.height * 0.35,
            ),
            SizedBox(height: size.height * 0.03),
            RoundedInputField(
              hintText: "email",
              onChanged: (value) {
                _email = value;
              },
            ),
            RoundedInputField(
              hintText: "Full Name",
              onChanged: (value) {
                _name = value;
              },
            ),
            RoundedInputField(
              hintText: "Your Username",
              onChanged: (value) {
                _username = value;
              },
            ),
            RoundedPasswordField(
              onChanged: (value) {
                setState(() {
                  _password  = value;
                });
              },
            ),
            RoundedInputField(
              hintText: "Mobile Number",
              onChanged: (value) {
                setState(() {
                  _age = int.parse(value);
                });
              },
            ),
            RoundedInputField(
              hintText: "Age",
              onChanged: (value) {
                _age =int.parse(value);
              },
            ),
            RoundedInputField(
              hintText: "Years of Experience",
              onChanged: (value) {
                _experience =int.parse(value);
              },
            ),
            RoundedButton(
              text: "SignUp",
              press: () => _onLogin(),
            ),
            SizedBox(height: size.height * 0.03),
            // AlreadyHaveAnAccountCheck(
            //   press: () {
            //     Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) {
            //           return SignUpScreen();
            //         },
            //       ),
            //     );
            //   },
            // ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: _body(size),
    );
  }
}