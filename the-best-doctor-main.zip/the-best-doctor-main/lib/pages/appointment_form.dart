import 'package:best_doctor/pages/dashboard_doc.dart';
import 'package:best_doctor/services/database_service.dart';
import 'package:flutter/material.dart';
import 'package:best_doctor/pages/background.dart';
import 'package:best_doctor/common_widgets/rounded_button.dart';
import 'package:flutter_svg/svg.dart';

import '../services/database_service.dart';
import 'dashboard_page.dart';
class AppFormScreen extends StatefulWidget {
  const AppFormScreen({Key? key}) : super(key: key);

  @override
  _AppFormScreenState createState() => _AppFormScreenState();
}

class _AppFormScreenState extends State<AppFormScreen>{
  final DatabaseService _databaseService = DatabaseService();

  String date = "";
  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();
  bool? check1 = false;
  bool? check2 = false;

  String _username = '';
  // String _name = '';
  // String _email = '';
  String _password = '';
  // String _mobile_number = '';
  // int _age = 0;

  Future<void> _onSubmit() async {
    final username = _username;
    final password = _password;

    print({username, password});

    final doctor = await _databaseService.findDoctor(username, password);
    if(doctor == null){
      // Navigator.push(context, MaterialPageRoute(builder: (context){
      //   return SignUpScreen();
      // })
      // );
      // _showSnackBar(context, 'Incorrect Credentials');
      print('Incorrect Credentials');
    }
    else{
      Navigator.push(context, MaterialPageRoute(builder: (context){
        return DashboardDoc(doctor: doctor,);
      })
      );
    }
    print(doctor);


    // Navigator.pop(context);
  }

  Widget _body(Size size) {
    // Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.03),
            Text(
              "Create an Appointment",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30, color: Colors.deepPurple),
            ),
            Text(
              "We will match The Best Doctor for you!",
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
            ),
            SizedBox(height: size.height * 0.03),
            SvgPicture.asset(
              "assets/icons/app.svg",
              height: size.height * 0.35,
            ),
            SizedBox(height: size.height * 0.03),

            ElevatedButton(
              onPressed: () {
                _selectDate(context);
              },
              child: Text("Choose Date"),
            ),
            Text("${selectedDate.day}/${selectedDate.month}/${selectedDate.year}"),
            SizedBox(height: size.height * 0.03),
            ElevatedButton(
              onPressed: () {
                _selectTime(context);
              },
              child: Text("Choose Time"),
            ),
            Text("${selectedTime.hour}:${selectedTime.minute}"),
            Text("Choose Symptoms:"),
            Row(
              children: [
                SizedBox(width: size.width*0.3,),
                Text("Cough"),
                Checkbox(
                  value: check1,
                  onChanged: (value ){
                    setState(() {
                      check1 = value;
                    });
                  },
                ),
              ],
            ),
            Row(
              children: [
                SizedBox(width: size.width*0.3,),
                Text("Headache"),
                Checkbox(
                  value: check2,
                  onChanged: (value ){
                    setState(() {
                      check2 = value;
                    });
                  },
                ),
              ],
            ),
            RoundedButton(
              text: "Submit",
              press: () => _onSubmit(),
            ),
            SizedBox(height: size.height * 0.03),

          ],
        ),
      ),
    );
  }

  _selectDate(BuildContext context) async {
    final DateTime? selected = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2010),
      lastDate: DateTime(2025),
    );
    if (selected != null && selected != selectedDate)
      setState(() {
        selectedDate = selected;
      });
  }
  _selectTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: selectedTime,
      initialEntryMode: TimePickerEntryMode.dial,
    );
    if(timeOfDay != null && timeOfDay != selectedTime)
    {
      setState(() {
        selectedTime = timeOfDay;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: _body(size),
    );
  }
}