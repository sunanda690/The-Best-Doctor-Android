import 'package:best_doctor/models/doctor.dart';
import 'package:best_doctor/pages/dashboard_doc.dart';
import 'package:best_doctor/pages/home_page.dart';
import 'package:best_doctor/pages/signup_doc.dart';
import 'package:best_doctor/pages/signup_page.dart';
import 'package:best_doctor/services/database_service.dart';
import 'package:flutter/material.dart';
import 'package:best_doctor/pages/background.dart';
import 'package:best_doctor/common_widgets/rounded_button.dart';
import 'package:best_doctor/common_widgets/rounded_input_field.dart';
import 'package:best_doctor/common_widgets/rounded_password_field.dart';
import 'package:flutter_svg/svg.dart';

import '../services/database_service.dart';
import 'dashboard_page.dart';
class LoginDocScreen extends StatefulWidget {
  const LoginDocScreen({Key? key}) : super(key: key);

  @override
  _LoginDocScreenState createState() => _LoginDocScreenState();
}

class _LoginDocScreenState extends State<LoginDocScreen>{
  final DatabaseService _databaseService = DatabaseService();

  String _username = '';
  // String _name = '';
  // String _email = '';
  String _password = '';
  // String _mobile_number = '';
  // int _age = 0;

  Future<void> _onLogin() async {
    final username = _username;
    final password = _password;

    print({username, password});

    final doctor = await _databaseService.findDoctor(username, password);
    if(doctor == null){
      // Navigator.push(context, MaterialPageRoute(builder: (context){
      //   return SignUpScreen();
      // })
      // );
      // _showSnackBar(context, 'Incorrect Credentials');
      print('Incorrect Credentials');
    }
    else{
      Navigator.push(context, MaterialPageRoute(builder: (context){
        return DashboardDoc(doctor: doctor,);
      })
      );
    }
    print(doctor);


    // Navigator.pop(context);
  }

  Widget _body(Size size) {
    // Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "LOGIN as Doctor",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: size.height * 0.03),
            SvgPicture.asset(
              "assets/icons/login.svg",
              height: size.height * 0.35,
            ),
            SizedBox(height: size.height * 0.03),
            RoundedInputField(
              hintText: "Your Username",
              onChanged: (value) {
                _username = value;
              },
            ),
            RoundedPasswordField(
              onChanged: (value) {
                setState(() {
                  _password  = value;
                });
              },
            ),
            RoundedButton(
              text: "LOGIN",
              press: () => _onLogin(),
            ),
            SizedBox(height: size.height * 0.03),
            TextButton(
              style: TextButton.styleFrom(
                padding: const EdgeInsets.all(16.0),
                primary: Colors.deepPurple,
              ),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context){
                  return SignUpDocScreen();
                }));
              },
              child: Text('New here? create an account'),
            )
          ],
        ),
      ),
    );
  }
  void _showSnackBar(BuildContext context, String message) {

    final snackBar = SnackBar(content: Text(message));
    Scaffold.of(context).showSnackBar(snackBar);
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: _body(size),
    );
  }
}